"""
Agentic AI Gateway
==================

Production-grade LLM routing with automatic fallbacks, canary deployments,
and multi-provider support.

v0.3.0 Features:
- Model family definitions with default agent types
- Cross-provider model mappings (same intent across providers)
- Bedrock API auto-discovery for latest models
- Support for "latest:haiku" style model resolution
- create_gateway_for_type() factory function

Author: Tyler Canton
GitHub: https://github.com/tyler-canton
PyPI: https://pypi.org/project/agentic-ai-gateway/

Copyright (c) 2026 Tyler Canton. All rights reserved.
Licensed under the MIT License.
"""

from .gateway import (
    AIGateway as AgenticGateway,
    AIGatewayConfig as AgenticGatewayConfig,
    AIGatewayResponse as AgenticGatewayResponse,
    LLMProvider,
    BedrockProvider,
    OpenAIProvider,
    InMemoryMetrics,
    MetricsCollector,
    create_bedrock_gateway,
    create_openai_gateway,
    create_multi_provider_gateway,
    create_gateway_for_type,
)

from .models import (
    AgentType,
    Provider,
    ModelFamily,
    ModelMapping,
    get_model_for_type,
    get_agent_type_for_model,
    resolve_model_alias,
    # Bedrock model constants
    CLAUDE_4_OPUS,
    CLAUDE_4_SONNET,
    CLAUDE_4_HAIKU,
    CLAUDE_3_7_SONNET,
    US_CLAUDE_4_SONNET,
    BEDROCK_MODELS,
)

from .discovery import (
    BedrockDiscovery,
    DiscoveredModel,
    DiscoveryResult,
    discover_models,
    get_latest_model,
    get_models_for_type,
    get_cross_region_profile,
)

__version__ = "0.3.0"
__author__ = "Tyler Canton"
__author_email__ = "tylercanton808@gmail.com"
__license__ = "MIT"
__url__ = "https://github.com/tyler-canton/agentic-ai-gateway"
__all__ = [
    # Core Gateway
    "AgenticGateway",
    "AgenticGatewayConfig",
    "AgenticGatewayResponse",
    "LLMProvider",
    "BedrockProvider",
    "OpenAIProvider",
    "InMemoryMetrics",
    "MetricsCollector",

    # Factory Functions
    "create_bedrock_gateway",
    "create_openai_gateway",
    "create_multi_provider_gateway",
    "create_gateway_for_type",

    # Model Types & Mappings
    "AgentType",
    "Provider",
    "ModelFamily",
    "ModelMapping",
    "get_model_for_type",
    "get_agent_type_for_model",
    "resolve_model_alias",

    # Model Constants
    "CLAUDE_4_OPUS",
    "CLAUDE_4_SONNET",
    "CLAUDE_4_HAIKU",
    "CLAUDE_3_7_SONNET",
    "US_CLAUDE_4_SONNET",
    "BEDROCK_MODELS",

    # Discovery
    "BedrockDiscovery",
    "DiscoveredModel",
    "DiscoveryResult",
    "discover_models",
    "get_latest_model",
    "get_models_for_type",
    "get_cross_region_profile",
]
